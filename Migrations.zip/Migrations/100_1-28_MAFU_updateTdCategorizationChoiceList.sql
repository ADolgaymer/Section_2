-- Delete value 'Full TRS only' from choice list TDCategorization
DELETE FROM T_CHOICELIST WHERE ChoiceList = 'TDCategorization' AND ChoiceValue = 'Full TRS only'