-- incident 5149574

Update infobase Set list_val='CE' where object_value = 'configset'
